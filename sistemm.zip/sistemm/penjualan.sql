-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2025 at 05:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `penjualan`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` char(7) NOT NULL,
  `id_jenis_barang` char(7) DEFAULT NULL,
  `nama_barang` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `harga` bigint(20) DEFAULT NULL,
  `kedaluwarsa` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `id_jenis_barang`, `nama_barang`, `unit`, `harga`, `kedaluwarsa`) VALUES
('BA00001', 'JB00001', 'Indomilk', 'kotak', 6000, '2029-12-04'),
('BA00002', 'JB00002', 'Chocolatos', 'Pcs', 1000, '2027-12-04'),
('BA00003', 'JB00004', 'Indomie', 'Pcs', 3000, '2028-11-04'),
('BA00004', 'JB00003', 'Bimoli', 'Liter', 37000, '2030-12-27');

-- --------------------------------------------------------

--
-- Table structure for table `jenis_barang`
--

CREATE TABLE `jenis_barang` (
  `id_jenis_barang` char(7) NOT NULL,
  `jenis_barang` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jenis_barang`
--

INSERT INTO `jenis_barang` (`id_jenis_barang`, `jenis_barang`) VALUES
('JB00001', 'Minuman'),
('JB00002', 'Makanan Ringan'),
('JB00003', 'Minyak'),
('JB00004', 'Mie');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(11) NOT NULL,
  `nama_pelanggan` varchar(255) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `nomor_hp` char(15) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama_pelanggan`, `jenis_kelamin`, `nomor_hp`, `alamat`) VALUES
(1, 'rizky', 'L', '085456543211', 'Naru Timurr'),
(2, 'Zoro', 'L', '085456543222', 'east blue');

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `id_penjualan` int(11) NOT NULL,
  `id_struk` char(13) DEFAULT NULL,
  `id_pelanggan` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_barang` char(7) DEFAULT NULL,
  `tanggal_pembelian` datetime DEFAULT NULL,
  `jumlah_pembelian` int(11) DEFAULT NULL,
  `status_pembelian` enum('Terjual','Belum Terjual') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`id_penjualan`, `id_struk`, `id_pelanggan`, `id_user`, `id_barang`, `tanggal_pembelian`, `jumlah_pembelian`, `status_pembelian`) VALUES
(1, '68177e7fa9836', 1, 1, 'BA00002', '2025-05-04 22:49:00', 5, 'Terjual'),
(2, '68177e7fa9836', 1, 1, 'BA00003', '2025-05-04 22:49:00', 7, 'Terjual'),
(3, '68177f93a537f', 2, 1, 'BA00001', '2025-05-04 22:54:00', 4, 'Terjual'),
(4, '6817811bd960c', 2, 1, 'BA00004', '2025-05-04 23:00:00', 2, 'Terjual'),
(5, '68178309f114c', 2, 1, 'BA00002', '2025-05-04 23:08:00', 10, 'Terjual');

-- --------------------------------------------------------

--
-- Table structure for table `stok_barang`
--

CREATE TABLE `stok_barang` (
  `id_stok_barang` char(15) NOT NULL,
  `id_barang` char(7) DEFAULT NULL,
  `tanggal_masuk` datetime DEFAULT NULL,
  `jumlah_masuk` int(11) DEFAULT NULL,
  `terjual` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stok_barang`
--

INSERT INTO `stok_barang` (`id_stok_barang`, `id_barang`, `tanggal_masuk`, `jumlah_masuk`, `terjual`) VALUES
('ST681773136A4AC', 'BA00002', '2025-05-04 08:00:00', 100, 0),
('ST68177343129DC', 'BA00003', '2025-05-01 08:01:00', 120, 0),
('ST6817736099170', 'BA00001', '2025-05-03 10:01:00', 100, 0),
('ST68177497EF6B4', 'BA00004', '2025-05-02 11:07:00', 50, 0),
('ST68177E92728AA', 'BA00002', '2025-05-04 22:49:54', 0, 5),
('ST68177E92737D0', 'BA00003', '2025-05-04 22:49:54', 0, 7),
('ST68177F9EC56D8', 'BA00001', '2025-05-04 22:54:22', 0, 4),
('ST68178126987E0', 'BA00004', '2025-05-04 23:00:54', 0, 2),
('ST68178318D20CB', 'BA00002', '2025-05-04 23:09:12', 0, 10);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama_user`, `username`, `password`) VALUES
(1, 'Sahnimm', 'admin', '21232f297a57a5a743894a0e4a801fc3'),
(3, 'Fahiraaaaaa', 'fahira', 'bb648e8f7447085cf0a4dbfa46cb1ea2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `jenis_barang`
--
ALTER TABLE `jenis_barang`
  ADD PRIMARY KEY (`id_jenis_barang`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`id_penjualan`);

--
-- Indexes for table `stok_barang`
--
ALTER TABLE `stok_barang`
  ADD PRIMARY KEY (`id_stok_barang`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `id_penjualan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
